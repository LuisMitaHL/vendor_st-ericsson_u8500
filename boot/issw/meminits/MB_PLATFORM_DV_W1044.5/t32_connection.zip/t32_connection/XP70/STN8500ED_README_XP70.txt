=======================================================
STN8500 - Howto Bring up XP70 debugger on 8500ED board
=======================================================

1) Edit T32 connection config file : XP70/ndk_config_xp70.t32
=> If using ETH connection, change NODE to IP@ of your Lauterbach probe.

[inside a DOS command line prompt]
2) Start T32MARM to act as a server for XP70 Debugger:
start t32marm.exe -c ndk_config_xp70.t32

[inside T32MARM]
3) STN8500 ARM A9 SS initialisation
-----------------------------------
do init_8500.cmm ed n smp ==> to bring up A9 SS in SMP, no hot_attach
do init_sxa_prcmu_debug.cmm ed prcmu ==> to activate APE XP70 [PRCMU] (clk activation, rst released)

[editing XP70 Toolset files]
-----------------------------------
4) After installation of XP70 toolset :
	- go to $SX/bin
	- edit target.ini file as follow : add below project to EMULATION section

[sx_debug_8500_prcmu]
Rule=target:type EMU
Rule=define MEMEC
Section=Core
Section=Common
Section=Memory_Map
OwnerParam=<BEGIN>
  connect T32 -h gnb302092.gnb.st.com:20000 -irlen 6 5 4 4 -tap 1
  config thread_timeout 10000
<OWNER PARAM END>

[Connecting XP70 Debugger on PRCMU]
-----------------------------------
5) In a DOS or Linux shell command window
	- go to the dir containing your XP70 application (ex: myprcmu_fw.out)
	- Open SxRUN console : sxrun -i -target=sx_debug_8500_prcmu myprcmu_fw.out
	- Download the program in XP70 memory space : > download
	- Once done, you should see "CONNECT OK" info message, as well as Device_Id value read.