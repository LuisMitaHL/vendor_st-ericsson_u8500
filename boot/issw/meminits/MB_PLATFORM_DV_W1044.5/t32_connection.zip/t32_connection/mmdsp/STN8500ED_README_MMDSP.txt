STN8500 - Howto Bring up T32MMDSP debugger
===========================================

[HW Setup]
 * Ensure you have : MOP500 board, 4V Power Supply, LA7707+Combiprobe, MIPI Connector, Lauterbach Power Supply
 * Connect Combiprobe on MIPI34 board connector
 * Connect 4V Power Supply on Power connector J2201 (external 4V power supply)

[SW Setup - Preliminary]
 * Assuming T32 is installed under C:\T32 dir on Win32 OS
 * Assuming T32 is installed under /home/user_name/T32 dir on Linux OS
 * Ensure your PATH env variable includes path to <T32_install_root> dir
 * Ensure your PATH env variable includes path to <T32_install_root>/bin dir

[starting T32MARM]
 >> Create or edit files ndk_config_t32_arm.t32 & ndk_config_t32_arm.t32 (see Appendix)
 >> you MUST create TEMP directory before starting T32 
Win32 : start t32marm.exe -c ndk_config_t32_arm.t32
Linux : t32marm -c ndk_config_t32_arm.t32

[inside T32MARM]
>> ARM CA9 SS initialisation
-----------------------------
do init_8500.cmm ed n smp ==> to bring up A9 SS in SMP, no hot_attach
do init_sxa_prcmu_debug.cmm ed sia_sva ==> to activate MMDSP[SxA] (clk activation, rst released)

[starting T32MMDSP]
!! CA9 SS must have been initialised first. MMDSP[SxA] must be active (clk, rst) - see previous 
Win32 : start t32mmdsp.exe -c ndk_config_t32_mmdsp.t32
Linux : t32mmdsp -c ndk_config_t32_mmdsp.t32

[inside T32MMDSP]
>> MMDSP Debugger setup
-----------------------
8500ED SVA : do init_8500_SxA_MMDSP.cmm ed v slave
8500ED SIA : do init_8500_SxA_MMDSP.cmm ed i slave

==> do sys.up or sys.m.attach to connect MMDSP Debugger to the core !!!
==> Be careful : sys.up = connection + core reset ; attach = connection, no core reset.

>> Configuration of MMDSP STbus Master
--------------------------------------
(can be run either on ARM or on MMDSP)
	-> SVA in ESRAM : do 8500_SxA_STbus_config.cmm ed v ESRAM
	-> SIA in ESRAM : do 8500_SxA_STbus_config.cmm ed i ESRAM
	-> SIA in DDR : do 8500_SxA_STbus_config.cmm ed v DDR
	-> SIA in DDR : do 8500_SxA_STbus_config.cmm ed i DDR

	
	
APPENDIX :
=========
Under Win32
-----------
ndk_config_t32_arm.t32 
	;== Environment variables				
	OS=
	ID=T32.ARM.CORE1
	TMP=C:\T32\TEMP\ARM-CORE1
	SYS=C:\T32

	IC=NETASSIST
	PORT=20001

	;== connexion params			
	PBI=
	CORE=1 
	;USB
	NET
	;NODE=<your_probe_DHCP_name>
	NODE=my_t32_probe.gnb.st.com


ndk_config_t32_mmdsp.t32
	;== Environment variables				
	OS=
	ID=T32.MMDSP
	TMP=C:\T32\TEMP\MMDSP-CORE2
	SYS=C:\T32

	IC=NETASSIST
	PORT=20002

	;== eth connexion params			
	PBI=
	CORE=2
	;USB
	NET
	;NODE=<your_probe_DHCP_name>
	NODE=my_t32_probe.gnb.st.com

Under Linux
-----------
ndk_config_t32_arm.t32 
	;== Environment variables				
	OS=
	ID=T32.ARM.CORE1
	TMP=/home/user_name/T32/TEMP/ARM-CORE1
	SYS=/home/user_name/T32

	IC=NETASSIST
	PORT=20001

	;== connexion params			
	PBI=
	CORE=1 
	;USB
	NET
	;NODE=<your_probe_DHCP_name>
	NODE=my_t32_probe.gnb.st.com


ndk_config_t32_mmdsp.t32
	;== Environment variables				
	OS=
	ID=T32.MMDSP.CORE2
	TMP=/home/user_name/T32/TEMP/MMDSP-CORE2
	SYS=/home/user_name/T32

	IC=NETASSIST
	PORT=20002

	;== eth connexion params			
	PBI=
	CORE=2
	;USB
	NET
	;NODE=<your_probe_DHCP_name>
	NODE=my_t32_probe.gnb.st.com
