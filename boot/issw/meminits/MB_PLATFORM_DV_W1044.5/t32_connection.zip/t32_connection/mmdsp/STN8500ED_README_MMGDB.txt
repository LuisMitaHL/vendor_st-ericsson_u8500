=======================================================
STN8500 - Howto Bring up MMGDB debugger on 8500ED board
=======================================================

[HW Setup]
 * Ensure you have : MOP500 board, 4V Power Supply, LA7707+Combiprobe, MIPI Connector, Lauterbach Power Supply
 * Connect Combiprobe on MIPI34 board connector
 * Connect 4V Power Supply on Power connector J2201 (external 4V power supply)

[SW Setup - Preliminary]
 * Assuming T32 is installed under C:\T32 dir on Win32 OS
 * Assuming T32 is installed under /home/user_name/T32 dir on Linux OS
 * Ensure your PATH env variable includes path to <T32_install_root> dir
 * Ensure your PATH env variable includes path to <T32_install_root>/bin dir

[starting T32MARM]
 >> Create or edit files ndk_config_t32_arm.t32 & ndk_config_t32_arm.t32 (see Appendix)
 >> you MUST create TEMP directory before starting T32 
Win32 : start t32marm.exe -c ndk_config_t32_arm.t32
Linux : t32marm -c ndk_config_t32_arm.t32

[inside T32MARM]
>> ARM CA9 SS initialisation
-----------------------------
do init_8500.cmm ed n smp ==> to bring up A9 SS in SMP, no hot_attach
do init_sxa_prcmu_debug.cmm ed sia_sva ==> to activate MMDSP[SxA] (clk activation, rst released)

>> Configuration of MMDSP STbus Master
--------------------------------------
	-> SVA in ESRAM : do 8500_SxA_STbus_config.cmm ed v ESRAM
	-> SIA in ESRAM : do 8500_SxA_STbus_config.cmm ed i ESRAM
	-> SIA in DDR : do 8500_SxA_STbus_config.cmm ed v DDR
	-> SIA in DDR : do 8500_SxA_STbus_config.cmm ed i DDR

!!!
!!! KEEP T32MARM window open. It will be used by MMGDB as debug server session. !!!
!!!

	
[starting MMGDB]
	- Open a shell console
	- Edit MMGDB hw_targets.cfg file according to appendix here below
	- connect on MOP500 v1.0 or MOP500 v2.0 board using the 8500ED target declared in hw_targets.cfg


========
APPENDIX
========
	
[ T32MARM - .t32 file editings]

Under Win32
-----------
ndk_config_t32_arm.t32 
	;== Environment variables				
	OS=
	ID=T32.ARM.CORE1
	TMP=C:\T32\TEMP\ARM-CORE1
	SYS=C:\T32

	RCL=NETASSIST
	PACKLEN=1024
	PORT=20001

	;== connexion params			
	PBI=
	CORE=1 
	;USB
	NET
	;NODE=<your_probe_DHCP_name>
	NODE=my_t32_probe.gnb.st.com


Under Linux
-----------
ndk_config_t32_arm.t32 
	;== Environment variables				
	OS=
	ID=T32.ARM.CORE1
	TMP=/home/user_name/T32/TEMP/ARM-CORE1
	SYS=/home/user_name/T32

	RCL=NETASSIST
	PACKLEN=1024
	PORT=20001

	;== connexion params			
	PBI=
	CORE=1 
	;USB
	NET
	;NODE=<your_probe_DHCP_name>
	NODE=my_t32_probe.gnb.st.com

	
	
[ MMGDB - hw_targets.cfg editings]

Add T32 communication protocol:
======================

tema_t32:
type="MC_TAP_CLIENT"
protocol="T32"
connect="T32 -h <T32MARM_host_name>:<port> -irlen <JTAG_TAP_CHAIN topology> -tap <MMDSP TAP position>"

;Examples
;;8820
;connect="T32 -h gnx757:20001 -irlen 4 5 4 -tap 0"
;;8815
;connect="T32 -h gnx2501:20001 -irlen 4 5 -tap 0"
;;8500_ed
;connect="T32 -h gnx2446:20001 -irlen 5 4 4 4 -tap 1"



Update MMGDB project list by adding :
=====================================

;---------------------------------------------
[STn8500ed video]
;---------------------------------------------
board="HAMAC_FPGA_EVB"
chip="hamacv"
emulation:
;<existing protocols>
com="tema_t32"

;---------------------------------------------
[STn8500ed imaging]
;---------------------------------------------
board="HAMAC_FPGA_EVB"
chip="hamaci"
emulation:
;<existing protocols>
com="tema_t32"
