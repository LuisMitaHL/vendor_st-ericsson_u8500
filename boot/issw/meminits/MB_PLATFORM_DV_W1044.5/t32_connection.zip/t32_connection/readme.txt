This directory contains scripts for Lauterbach T32

Launch the debug session
------------------------

In Windows environment : launch "t32cde usb" script  in a cygwin windows, or launch "dualdebug.bat" batch file in a DOS command windows
In Unix environment (for Le Mans users) : launch "t32cde <icd_number>"



Directory 	FileName 		Lang 	Purpose 
--------------------------------------------------------
./
 		t32cde 			shell 	Unix script to Launch Trace32 sessions for Cortex-A9 (#0) and Cortex-R4 (L2).
						"��reset��, ��i�� and ��X�� buttons display are also in the scope of this launching."
						"For Windows OS, you must launch this script from a cygwin windows "
		dualdebug.bat   bat     Windows batch to Launch Trace32 sessions for Cortex-A9 (#0) and Cortex-R4 (L2)
		my_t32config_1.usb      Config file used by dualdebug.bat
		my_t32config_2.usb      Config file used by dualdebug.bat

		t32.cmm 		cmm 	Lauterbach customization startup script 
 		checkbox 		cmm 	Debug session configuration (called by ��i�� button) 
 		reset.cmm 		cmm 	"Control DB8500 APE and ModemSS reset, relaying on the scripts below "
 		exit.cmm 		cmm	    Close all Lauterbach Trace32 windows (called by ��X�� button) 
 		general_gui_setting	cmm 	GUI settings 
		general_path_setting	cmm 	Path settings 
		semihosting_setting	cmm	Semihosting settings 
		view_per.cmm		cmm 	Peripherals display script
		CortexA9MP.per		per 	Cortex and 8500 specific registers description 
		DB8500_ED.per		per
		DB8500_V1.per 		per
		DB8500_V2.per 		per
		mmu.cmm 		cmm 	Toggle MMU ON/OFF 
		i2c_read.cmm    cmm 	 
		expert_dialog.cmm       Use to configure debug session

./debug_ape
	 	init_8500.cmm 		cmm 	Initialise Trace32 session on APE 
	 	8500_debug_config_a9ss	cmm 	Initialise APE (Cortex-A9) session 
	 	8500_debug_config_SVP	cmm 	Initialise SVP (virtual platform) debug session 
	 	init_sxa_prcmu_debug	cmm 	Summarize memory accesses for setting up SxA or XP70[PRCMU] debug session 
		cross_trig_a9_sxa.cmm   cmm     For cross-triggering
		cross_trig_ape_mod.cmm  cmm     For cross-triggering
		cti.cmm                 cmm     For cross-triggering
		set_cti_bases.cmm       cmm     For cross-triggering
		dbg_through_reset.cmm   cmm     
		mod_nopwrdwn.cmm        cmm

./mem_init 
		8500_ed_XXXmhz.cmm	cmm 	Initialise SoC PLL (APE+ModemSS) and SDMC (LpDDR) 
		mop_xx_.cmm 		
		href_xx.cmm		
		db8500xx.cmm 		
	 	prcmufw_xx.bin		bin 	PRCMU firmware to load when working without Rom code (REMAP mode) 

./load_ape
		load_8500.cmm 		cmm 	Load APE binaries in LpDDR.
						Load symbols for debug.
						Set Cortex-A9 (#0) Program Counter (PC). To customize by the user. 

./debug_modem
	 	init_8500_ModemSS.cmm 	cmm 	Initialise Trace32 session on ModemSS side 
		8500_debug_config_modem	cmm 	Initialise ModemSS (Cortex R4) session 

./load_modem
	 	load_8500_ModemSS.cmm 	cmm 	"Load ModemSS binaries in LpDDR (L1 and L2 images, Dynamic Objects) and TCM (IPL). Load symbols for debug."
						Set Cortex-R4 (L2) Program Counter (PC). To customize by user. 
./XP70	
		SIA_XP70_GPIO_setting.cmm	XP70 specific scripts

./mmdsp 	
		8500_SxA_STbus_config.cmm	MMDSP specific scripts
		8500_T32MMDSP_init.cmm		
		AHB_Config_for_SxA_ext_mem_access.cmm		
		mmterm.cmm		
		read_ind_reg.cmm		
		write_ind_reg.cmm		
		write_mmdsp_ind_reg.cmm		

./misc_init 	hsi_modem_config.cmm	cmm 	Miscellanous scripts
		ssp0_4500.cmm		
		ape_i2c_4500.cmm		
		ssp0_4500_vaux3.cmm		
		ssp0_4500_vsmps3.cmm		

./peps	
	dbahn_8500_setup.cmm	cmm 		PEPS specific scripts
	dbahn_8500_setup_128mbytes.cmm		
	dbahn_8500_setup_256mbytes.cmm		
	fsmc_setup.cmm		

./trace_config 					
	etm_config.cmm	cmm 			ETM/PTM/STM trace config	 
	ptm_config.cmm		
	stm_config.cmm		
	changeCoreTraceFreq.cmm		
	stm_modem_ape_config.cmm		
	trace_config.cmm		

./user_config 	
	linux_settings.cmm	cmm 		User configuration scripts
	modem_image_config.cmm		
	second_core.cmm		
	user_config;cmm 		
